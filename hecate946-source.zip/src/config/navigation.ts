export interface HeaderNavItem {
  label: string;
  href: string;
  /** Additional routes that should mark this item as current. */
  match?: readonly string[];
}

/**
 * Add, remove, or reorder navigation tabs here.
 * The header automatically redistributes the available tab space.
 */
export const headerNavigation = [
  { label: 'About', href: '/about/' },
  { label: 'Resume', href: '/resume/' },
  {
    label: 'Projects',
    href: '/projects/',
    match: ['/code/', '/clarinet/', '/piano/', '/lab/'],
  },
  { label: 'Contact', href: '/contact/' },
  { label: 'Stats', href: '/stats/' },
] as const satisfies readonly HeaderNavItem[];
